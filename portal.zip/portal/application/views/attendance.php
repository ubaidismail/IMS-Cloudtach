<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($_SESSION['login'])) {
    
}else{
    echo 'somethig went wrong';
    redirect('LoginController');
}
include "inc/header.php";
?>

<body class="sb-nav-fixed">
    <?php include "inc/nav.php"; ?>
    <div id="layoutSidenav">
        <?php include "inc/sidenav.php"; ?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Attendance</h1>
                </div>
            </main>
            <?php
	include "inc/footer.php";
?>