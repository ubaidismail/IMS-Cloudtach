<?php
defined('BASEPATH') OR exit('No direct script access allowed');
// if (isset($_SESSION['login'])) {
//   redirect('LoginController/login_func');
// }

include "inc/header.php";
?>

<body>

    <div class="container">
        <div class="login-form mt-5">
          <div class="login-logo"><img src="<?php echo base_url('admin-assets/img/login-logo.png'); ?>" alt=""></div>
            <h3>Portal Login</h3>
            <?php echo form_open('LoginController/login_func'); ?>
            <div class="form-group">
                <label for="exampleInputEmail1">Name</label>
                <input type="name" class="form-control" name="name" placeholder="Enter name">
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1">Password</label>
                <input type="password" class="form-control" name="password" placeholder="Password">
            </div>
            <button type="submit" class="btn btn-primary" name="submit-login">Login</button>
            </form>
        </div>
    </div>
    <?php
	include "inc/footer.php";
	?>

</body>

</html>