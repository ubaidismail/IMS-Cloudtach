<?php

defined('BASEPATH') OR exit('Your are not allowed to access this asset');

class AdminController extends CI_Controller{

    function index(){
        $this->load->view('dashboard');
    }
    function attendance(){
        $this->load->view('attendance');
    }
   

}
?>
