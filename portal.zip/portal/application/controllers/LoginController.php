<?php

defined('BASEPATH') OR exit('Your are not allowed to access this asset');

class LoginController extends CI_Controller{
    function index(){
        $this->load->view('join');
    }
    function login_func(){
             $name = $this->input->post('name');
             $pass = md5($this->input->post('password'));
             if(!empty($name || $pass)){
                 $this->load->model('LoginModel');
                 $get_register_user = $this->LoginModel->get_user_login_details($name , $pass);
                 if($get_register_user){
                    $_SESSION['login'] = 'login';
                      $this->load->view('dashboard' , ['name' => $name]);
                 }else{
                     echo 'Please enter correct username or password';
                 }
             }
        
    }
    function logout_cp(){
        $logout = session_destroy();
        if($logout){
            redirect('LoginController');
        }else{
            echo 'something went wrong';
        }
    }
}
?>