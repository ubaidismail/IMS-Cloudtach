<?php
class LoginModel extends CI_Model{

	function get_user_login_details($name , $pass){
		// if(!empty($name && $pass)){
			$query = $this->db->get_where('cd_register' ,['name' => $name , 'password' => $pass])->result();
			// exit;
			return $query;
		// }
	}
}